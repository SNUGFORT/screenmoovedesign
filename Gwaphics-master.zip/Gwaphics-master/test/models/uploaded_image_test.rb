require 'test_helper'

class UploadedImageTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
