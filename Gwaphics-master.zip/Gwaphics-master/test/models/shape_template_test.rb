require 'test_helper'

class ShapeTemplateTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
