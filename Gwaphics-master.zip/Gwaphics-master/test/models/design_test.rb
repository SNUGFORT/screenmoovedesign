require 'test_helper'

class DesignTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
