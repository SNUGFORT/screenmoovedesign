export const UPDATE_MODE = 'UPDATE_MODE';

export const updateMode = (mode) => ({
  type: UPDATE_MODE,
  mode,
});
