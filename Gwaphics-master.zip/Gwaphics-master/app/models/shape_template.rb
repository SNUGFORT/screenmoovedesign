class ShapeTemplate < ApplicationRecord
  validates :type, presence: true
end
